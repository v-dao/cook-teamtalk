#include <boost/thread.hpp>

int main(int argc, char** argv){
	boost::thread th;
	return 0;
}
