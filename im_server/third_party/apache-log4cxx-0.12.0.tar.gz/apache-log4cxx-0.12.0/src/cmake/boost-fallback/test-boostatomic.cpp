#include <boost/atomic.hpp>

int main(int argc, char** argv){
	boost::atomic<bool> b;
}

